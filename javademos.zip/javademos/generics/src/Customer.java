public class Customer {
    int id;
    String firstName;
}
