public class MyList<T> {
    public void add(T value){

    }

    public void remove(T value){

    }
}
