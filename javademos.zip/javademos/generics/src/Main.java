import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
	    MyList<Customer> sehirler=new MyList<Customer>();
	    sehirler.add(new Customer());
	    sehirler.add(new Customer());
    }
}
