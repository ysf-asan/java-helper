public class Robot implements IWorkable {
    @Override
    public void work() {

    }
}
