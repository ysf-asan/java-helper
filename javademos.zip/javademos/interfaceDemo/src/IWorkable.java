public interface IWorkable {
    void work();
    //mesai
}
