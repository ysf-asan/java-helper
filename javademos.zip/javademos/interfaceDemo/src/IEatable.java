public interface IEatable {
    void  eat();
}
