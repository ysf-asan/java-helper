public interface IPayable {
    void  pay();
}
