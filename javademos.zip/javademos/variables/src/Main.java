public class Main {

    public static void main(String[] args) {
        int ogrenciSayisi = 12;
        String mesaj ="Öğrenci sayısı : ";
        System.out.println(mesaj + ogrenciSayisi);
        System.out.println(mesaj + ogrenciSayisi);
        System.out.println("Öğrenci sayım : "+ ogrenciSayisi);
        System.out.println("Öğrenci sayım : "+ ogrenciSayisi);
        System.out.println("Öğrenci sayım : "+ ogrenciSayisi);
    }
}
