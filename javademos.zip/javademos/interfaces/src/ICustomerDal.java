public interface ICustomerDal {
    void Add();
}
