package matematik;

public class Logaritma {
    public double logaritmaHesapla(){
        return 1;
    }
}
