public class Product implements IEntity {
}
