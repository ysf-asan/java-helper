public interface IEntity {
}
