public class ProductDal implements IEntityRepository<Product> {
    @Override
    public void add(Product entity) {

    }

    @Override
    public void delete(Product entity) {

    }

    @Override
    public void update(Product entity) {

    }
}
