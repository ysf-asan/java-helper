public class Validator {
    public <T extends IEntity> void validate(T entity){

    }
}
