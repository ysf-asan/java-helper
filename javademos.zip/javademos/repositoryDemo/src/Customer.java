public class Customer implements IEntity{
}
