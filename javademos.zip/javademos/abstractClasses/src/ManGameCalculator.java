public class ManGameCalculator extends  GameCalculator{
    @Override
    public void  hesapla(){
        System.out.println("Puanınız : 90");
    }
}
