public class KidsGameCalculator  extends GameCalculator{

    @Override
    public void hesapla() {

    }
}
