public class OlderGameCalculator extends GameCalculator{
    @Override
    public void hesapla() {

    }
}
