public class Product {
    int id;
    String name;
    double price;
}
