public class DatabaseHelper {
    public static class Crud{ //Create read update delete
        public static void  Delete(){

        }
        public static void  Update(){

        }
    }

    public static class Connection{
        public static void createConnection(){

        }
    }
}
