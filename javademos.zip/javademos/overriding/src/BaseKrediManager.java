public class BaseKrediManager {
    public double hesapla(double tutar){
        return tutar * 1.18;
    }
}
