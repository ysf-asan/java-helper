public class TarimKrediManager extends BaseKrediManager {
}
