public class Main {

    public static void main(String[] args) {
	   double sayi = 12.5;
	   sayi = -129;

	   char karakter = 'A';

	   boolean dogruMu=false;

    }
}
