import java.io.Console;

public class CustomerManager extends PersonManager{

}
