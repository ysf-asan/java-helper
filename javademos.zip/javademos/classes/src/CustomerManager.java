public class CustomerManager{
    public void Add(){
        System.out.println("Müşteri eklendi");
    }

    public void Remove(){
        System.out.println("Müşteri silindi");
    }

    public void Update(){
        System.out.println("Müşteri güncellendi");
    }
}