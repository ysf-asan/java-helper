public class BaseLogger {
    public void  log(String message){
        System.out.println("Default logger : "+ message);
    }
}
